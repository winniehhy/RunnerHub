// document.querySelectorAll('.product-img-1').forEach(image_1 => {
//   image_1.addEventListener('click', () => {
//     var scr = image_1.getAttribute('src');
//     document.querySelector('.main-img-1').src = src;
//   });
// });

// document.querySelectorAll('.product-img-1').forEach(image_1 => {
//   image_1.addEventListener('click', () => {
//     var scr = image_1.getAttribute('src');
//     document.querySelector('.main-img-1').src = scr;
//   });
// });

// document.querySelectorAll('.product-img-1').forEach(image_1 => {
//   image_1.addEventListener('click', () => {
//     var src = image_1.getAttribute('src');
//     document.querySelector('.main-img-1').src = src;
//   });
// });


document.addEventListener('DOMContentLoaded', () => {
  const thumbnailImages = document.querySelectorAll('.product-img-1');
  const mainImage = document.querySelector('.main-img-1');

  thumbnailImages.forEach((thumbnail) => {
    thumbnail.addEventListener('click', () => {
      const src = thumbnail.getAttribute('src');
      mainImage.src = src;
    });
  });
});

document.addEventListener('DOMContentLoaded', () => {
  const thumbnailImages = document.querySelectorAll('.product-img-2');
  const mainImage = document.querySelector('.main-img-2');

  thumbnailImages.forEach((thumbnail) => {
    thumbnail.addEventListener('click', () => {
      const src = thumbnail.getAttribute('src');
      mainImage.src = src;
    });
  });
});

document.addEventListener('DOMContentLoaded', () => {
  const thumbnailImages = document.querySelectorAll('.product-img-3');
  const mainImage = document.querySelector('.main-img-3');

  thumbnailImages.forEach((thumbnail) => {
    thumbnail.addEventListener('click', () => {
      const src = thumbnail.getAttribute('src');
      mainImage.src = src;
    });
  });
});



